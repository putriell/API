package com.example.retrofitapi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

interface API {
    @GET("/photos")
    Call<List<RetroPhoto>> getAllPhotos();
}
